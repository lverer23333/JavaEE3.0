package edu.bjtu.ee4j.config;

import edu.bjtu.ee4j.services.PersonListener;
import edu.bjtu.ee4j.stream.PersonStreams;
import edu.bjtu.ee4j.stream.VIPStreams;

import org.springframework.cloud.stream.annotation.EnableBinding;
import org.springframework.context.annotation.Configuration;

@EnableBinding(value={PersonStreams.class,VIPStreams.class})
public class StreamsConfig {
}
