package edu.bjtu.ee4j.services;

import edu.bjtu.ee4j.domain.Person;
import edu.bjtu.ee4j.domain.VIP;
import edu.bjtu.ee4j.stream.PersonStreams;
import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.stream.annotation.StreamListener;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Component;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.servlet.ModelAndView;

import java.io.UnsupportedEncodingException;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Component
@Slf4j
public class PersonListener {
    
    private PersonService PersonService;
    private VIPService vipService;

    @Autowired
    public void setPersonService(PersonService PersonService,VIPService vipService) {
        this.PersonService = PersonService;
        this.vipService = vipService;
    }
    
    @StreamListener(PersonStreams.INPUT)

    public void handleGreetings(Person person) {
  
    	//Logger LOG = LoggerFactory.getLogger("SpringKafkaStream");
        //LOG.info("Received greetings: {}", person);
    	boolean judge=true;
    	  System.out.println("我是person");
     
 
      if(this.PersonService.getUser(person.getEmail())!=null){
    	  //model.addAttribute("err", "The email has been registered!");
    	  judge=false;
    //	  return new ModelAndView("/contact");
      }
      else if(this.PersonService.getUser1(person.getPhone_no())!=null){
    	 // model.addAttribute("err1", "The phone has been registered!");
    	  judge=false;
    	//  return new ModelAndView("/contact");
      }
   
        this.PersonService.savePerson(person);
     
    
        
         //model.addAttribute("hhh", "Login");
        // return new ModelAndView("/login");
    }
   
}
