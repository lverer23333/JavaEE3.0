package edu.bjtu.ee4j.services;



import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import org.springframework.stereotype.Service;
import org.springframework.ui.Model;

import org.springframework.validation.BindingResult;

import edu.bjtu.ee4j.domain.Person;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public interface PersonService {
    Iterable<Person> getAllPersons();
    Person getPersonById(Integer id);
    Person savePerson(Person person);
	void deletePerson(Integer id);

	public String getUser(String email);
	public String getUser1(String phone);
	public void sendPerson(final Person person);
  
	
}
