package edu.bjtu.ee4j.services;






import org.springframework.stereotype.Service;




import edu.bjtu.ee4j.domain.VIP;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public interface VIPService {
    Iterable<VIP> getAllPersons();
    VIP getPersonById(Integer id);
    VIP savePerson(VIP person);
	void deletePerson(Integer id);

	public String getUser(String email);
	public String getUser1(String phone);
	public void sendPerson1(final VIP person);
  
	
}
