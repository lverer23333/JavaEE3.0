package edu.bjtu.ee4j.controllers;

import edu.bjtu.ee4j.APIVersion.ApiVersion;
import edu.bjtu.ee4j.domain.Person;
import edu.bjtu.ee4j.domain.VIP;
import edu.bjtu.ee4j.domain_second.Coach;
import edu.bjtu.ee4j.domain_second.Course;

import edu.bjtu.ee4j.services.VIPService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;


import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;


import org.springframework.beans.factory.annotation.Autowired;




import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;


import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import org.springframework.web.servlet.ModelAndView;



@RestController("VIPController-v2")
@ApiVersion(2)


@Api(value="GYM_CLUB_VIP", description="Operations about VIP applying")
public class VIPController<R> {
    private VIPService CourseService;

    @Autowired
    public void setCourseService(VIPService CourseService) {
        this.CourseService = CourseService;
    }
    
  
    @ApiOperation(value = "VIP apply course")
    @RequestMapping(value = "/vip_deal", method = RequestMethod.POST,produces = "text/html")
    //@ResponseBody
    public ModelAndView VIP_DEAL(@Valid VIP vip, BindingResult bindingResult, Model model,HttpServletResponse response,HttpServletRequest request) {
    	 if (bindingResult.hasErrors()) {      
        	 return new ModelAndView("/vip");         
        }
    	  this.CourseService.sendPerson1(vip);     
          return new ModelAndView("/vip");
    }
    

}
