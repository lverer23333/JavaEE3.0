package edu.bjtu.ee4j.repository.primary;



import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import edu.bjtu.ee4j.domain.VIP;

@Repository
public interface VIPRepository extends CrudRepository<VIP, Integer>{

	@Query("select height from VIP where email = ?1")
    public String getByPasswordAndUsername(String email);
  //查询用户通过密码和姓名
	@Query("select height from VIP where phone = ?1")
    public String getByPasswordAndUsername1(String phone);
	
    
}
