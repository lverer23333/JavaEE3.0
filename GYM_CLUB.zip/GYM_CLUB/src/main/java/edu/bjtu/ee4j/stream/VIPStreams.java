package edu.bjtu.ee4j.stream;

import org.springframework.cloud.stream.annotation.Input;
import org.springframework.cloud.stream.annotation.Output;
import org.springframework.messaging.MessageChannel;
import org.springframework.messaging.SubscribableChannel;

public interface VIPStreams {
    String INPUT = "greetings-inVIP";
    String OUTPUT = "greetings-outVIP";

    @Input(INPUT)
    SubscribableChannel inboundGreetings1();

    @Output(OUTPUT)
    MessageChannel outboundGreetings1();
}
