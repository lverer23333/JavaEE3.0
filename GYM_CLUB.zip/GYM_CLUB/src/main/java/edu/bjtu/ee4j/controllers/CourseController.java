package edu.bjtu.ee4j.controllers;

import edu.bjtu.ee4j.APIVersion.ApiVersion;
import edu.bjtu.ee4j.domain_second.Coach;
import edu.bjtu.ee4j.domain_second.Course;
import edu.bjtu.ee4j.services.CourseService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import net.bytebuddy.build.HashCodeAndEqualsPlugin.ValueHandling.Sort;

import static org.springframework.hateoas.mvc.ControllerLinkBuilder.linkTo;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;

import javax.validation.Valid;

import org.hibernate.mapping.List;
import org.springframework.beans.factory.annotation.Autowired;


import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.data.web.PageableHandlerMethodArgumentResolver;
import org.springframework.data.web.PagedResourcesAssembler;
import org.springframework.hateoas.EntityLinks;
import org.springframework.hateoas.PagedResources;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;

import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.method.support.HandlerMethodArgumentResolver;
import org.springframework.web.servlet.ModelAndView;

import static org.springframework.hateoas.mvc.ControllerLinkBuilder.*;

@RestController("CourseController-v2")
@ApiVersion(2)


@Api(value="GYM_CLUB_Course", description="Operations about course querying")
public class CourseController<R> {
    private CourseService CourseService;

    @Autowired
    public void setCourseService(CourseService CourseService) {
        this.CourseService = CourseService;
    }
    
  
  
    @RequestMapping(value = "/query1/Course/{page}", method = RequestMethod.GET, produces = "text/html")
    @ApiOperation(value = "View a list of courses in the gym",response = Iterable.class)
 
   
    public ModelAndView course_query(@Valid Course Course,BindingResult bindingResult,Model model,@PathVariable("page") int page) {

    	Collection<Course> courses = new ArrayList<Course>();
    	PageRequest pageRequest = PageRequest.of(page, 4);
         Iterable<Course> iterable=this.CourseService.findAll(pageRequest);
         Iterator<Course> iterator1=iterable.iterator();
         while (iterator1.hasNext()) {
        	
           Course c= iterator1.next();
          
        	  courses.add(c);
           
         } 
        model.addAttribute("course",courses);
    	
  	  return new ModelAndView("/index");
       
    }
 
    /*
    @ApiOperation(value = "Search a course's detail information",response = Course.class)
    @RequestMapping(value = { "", "/course_detail/{course_name}"},produces = "text/html")
    public ModelAndView index1(@PathVariable String course_name ,Coach coach,Course course, Model model) {
        model.addAttribute("activePage", "contacts");
        
    	Course cour=this.CourseService.getCourse(course_name);
        model.addAttribute("cour", cour);
        
  	  return new ModelAndView("/index2");
    }
    */
  
    @Autowired private EntityLinks links;

   

    private String createLinkHeader(PagedResources <Course> pr) {
     final StringBuilder linkHeader = new StringBuilder();
     linkHeader.append(buildLinkHeader(pr.getLinks().get(0).getHref()+"/0", "first"));
     linkHeader.append(", ");
     for(int i=1;i<pr.getLinks().size();i++){
         linkHeader.append(buildLinkHeader(pr.getLinks().get(i).getHref()+"/"+String.valueOf(i), "next"));
         linkHeader.append(", ");
     }
    
 
     return linkHeader.toString();
    }

    public static String buildLinkHeader(final String uri, final String rel) {
     return "<" + uri + ">; rel=\"" + rel + "\"";
    }

}
