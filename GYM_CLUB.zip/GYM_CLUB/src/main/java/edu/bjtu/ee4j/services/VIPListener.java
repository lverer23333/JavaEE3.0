package edu.bjtu.ee4j.services;


import edu.bjtu.ee4j.domain.VIP;

import edu.bjtu.ee4j.stream.VIPStreams;
import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.stream.annotation.StreamListener;

import org.springframework.stereotype.Component;


@Component
@Slf4j
public class VIPListener {
    
    private VIPService PersonService;

    @Autowired
    public void setPersonService(VIPService VIPService) {
        this.PersonService = VIPService;
    }
    
    @StreamListener(VIPStreams.INPUT)
    public void handleGreetings(VIP vip) {
  
    	//Logger LOG = LoggerFactory.getLogger("SpringKafkaStream");
        //LOG.info("Received greetings: {}", person);
    	boolean judge=true;
       System.out.println("我是vip");
      
      if(this.PersonService.getUser(vip.getEmail())!=null){
    	  //model.addAttribute("err", "The email has been registered!");
    	  judge=false;
    //	  return new ModelAndView("/contact");
      }
      else if(this.PersonService.getUser1(vip.getPhone())!=null){
    	 // model.addAttribute("err1", "The phone has been registered!");
    	  judge=false;
    	//  return new ModelAndView("/contact");
      }
   
        this.PersonService.savePerson(vip);
      
        
         //model.addAttribute("hhh", "Login");
        // return new ModelAndView("/login");
    }
   
}
